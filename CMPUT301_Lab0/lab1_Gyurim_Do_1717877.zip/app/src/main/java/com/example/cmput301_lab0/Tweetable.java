package com.example.cmput301_lab0;

import java.util.Date;

public interface Tweetable {
    public String getMessage();
    public Date getDate();

}